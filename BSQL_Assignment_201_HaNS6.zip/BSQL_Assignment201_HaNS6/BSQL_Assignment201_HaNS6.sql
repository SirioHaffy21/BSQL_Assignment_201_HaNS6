-- Create a new database called 'EmployeeManagement_System'
-- Connect to the 'master' database to run this snippet
-------------------QUESTION 1----------------------------------
USE master
GO
-- Create the new database if it does not exist already
IF NOT EXISTS (
    SELECT [name]
        FROM sys.databases
        WHERE [name] = N'EmployeeManagement_System'
)
CREATE DATABASE EmployeeManagement_System
GO

-- Create a new table called '[EMPLOYEE]' in schema '[dbo]'
-- Drop the table if it already exists
IF OBJECT_ID('[dbo].[EMPLOYEE]', 'U') IS NOT NULL
DROP TABLE [dbo].[EMPLOYEE]
GO
-- Create the table in the specified schema
USE EmployeeManagement_System
GO
-------------EMPLOYEE--------------------------
CREATE TABLE [dbo].[EMPLOYEE]
(
    [EmpNo] VARCHAR(6) NOT NULL PRIMARY KEY, -- Primary Key column
    [EmpName] NVARCHAR(50) NOT NULL,
    [BirthDay] DATE,
    [DeptNo] INT NOT NULL,
    [MgrNo] INT NOT NULL,
    [StartDate] DATETIME,
    [Salary] MONEY,
    [Level] INT CHECK([Level] BETWEEN 1 AND 7) DEFAULT 1,
    [Status] INT CHECK([Status] BETWEEN 0 AND 2),
    [Note] TEXT
    -- Specify more columns here
);
GO
-------------SKILL----------------------------
CREATE TABLE [dbo].[SKILL]
(
    [SkillNo] INT PRIMARY KEY IDENTITY(1,1),
    [SkillName] NVARCHAR(50),
    [Note] TEXT
);
GO
-------------DEPARTMENT-----------------------
CREATE TABLE [dbo].[DEPARTMENT]
(
    [DeptNo] INT PRIMARY KEY IDENTITY(1,1),
    [DeptName] NVARCHAR(50),
    [Note] TEXT
);
GO
--------------EMP_SKILL-----------------------------
CREATE TABLE [dbo].[EMP_SKILL]
(
    [SkillNo] INT FOREIGN KEY REFERENCES SKILL(SkillNo),
    [EmpNo] VARCHAR(6) FOREIGN KEY REFERENCES EMPLOYEE(EmpNo),
    [SkillLevel] INT CHECK([SkillLevel] BETWEEN 1 AND 3),
    [RegDate] DATETIME,
    [Description] TEXT
    UNIQUE([SkillNo], [EmpNo])
);
GO
-------------------QUESTION 2------------------------
---------------  1 -----------------------------------
ALTER TABLE EMPLOYEE
ADD Email VARCHAR(50) NULL
GO
ALTER TABLE EMPLOYEE
ADD CONSTRAINT uq_Employee_Email UNIQUE(Email)
GO

---------------  2  ---------------------------------
ALTER TABLE EMPLOYEE 
ADD CONSTRAINT df_EMPLOYEE_MgrNo DEFAULT 0 FOR MgrNo
GO

ALTER TABLE EMPLOYEE 
ADD CONSTRAINT df_EMPLOYEE_Status DEFAULT 0 FOR [Status]
GO
-------------------QUESTION 3------------------------
-------------------  1  -------------------------------
ALTER TABLE EMPLOYEE
ADD CONSTRAINT FK_DeptNo
FOREIGN KEY (DeptNo) REFERENCES DEPARTMENT(DeptNo)
GO
-------------------  2  -------------------------------
ALTER TABLE EMP_SKILL
DROP COLUMN Description
-----------------  QUESTION 4  -----------------------
---------------------1---------------------------------
----------------SKILL------------------
INSERT INTO dbo.SKILL(SkillName, Note) VALUES
('Testing','have knowlegde for the tools of test'),
('Developing','have knowlegde for language programing'),
('Analysis','have knowlegde for reasoning'),
('Presentation','have knowlegde for standing in front of crowd'),
('Language','500toeic/7.0ielts'),
('Designing','have knowlegde for design Interfaces')
----------------DEPARTMENT----------------------------
INSERT INTO dbo.DEPARTMENT(DeptName, Note) VALUES
('Manager','Owner'),
('Accounting','quick calculation'),
('Human Resources','support all members'),
('Developer','always be the flagship of the company'),
('Tester','always support and collab with Dev'),
('Analsys','the root of the company')

------------------EMPLOYEE----------------------------
INSERT INTO dbo.EMPLOYEE(EmpNo, EmpName, BirthDay, DeptNo, MgrNo, StartDate, Salary, [Level], [Status], Note, Email) VALUES
('EM01','NGUYEN SY HA','2000-10-21', 1, 2, '2021-10-18 09:00:00', 100000.0, 7, 0, 'Nothing', 'syha@fsoft.com.vn'),
('EM02','C. RONALDO','1985-02-05', 3, 4, '2021-10-18 09:00:00', 40000.0, 3, 0, 'Nothing', 'CR7@fsoft.com.vn'),
('EM03','NGUYEN THANH TUNG','1994-07-05', 5, 5, '2021-10-25 09:00:00', 50000.0, 6, 0, 'Nothing', 'NTT@fsoft.com.vn'),
('EM04','L. MESSI','1987-04-20', 6, 2, '2021-10-11 09:00:00', 40000.0, 6, 0, 'Nothing', 'L10a@fsoft.com.vn'),
('EM05','NGUYEN THI NGOC','2000-10-31', 4, 3, '2021-10-18 09:00:00', 30000.0, 4, 0, 'Nothing', 'NTN@fsoft.com.vn'),
('EM06','TUYET MAI','2000-02-12', 5, 2, '2021-09-27 09:00:00', 60000.0, 5, 0, 'Nothing', 'TMI@fsoft.com.vn')
------------------EMP_SKILL----------------------------
INSERT INTO dbo.EMP_SKILL(SkillNo, EmpNo, SkillLevel, RegDate) VALUES
(5,'EM01',1,'2021-12-15 14:00:00'),
(2,'EM02',1,'2021-11-11 09:00:00'),
(4,'EM02',2,'2022-05-06 14:00:00'),
(6,'EM02',3,'2022-09-11 14:00:00'),
(3,'EM03',1,'2021-10-30 09:00:00'),
(4,'EM03',3,'2021-11-22 08:00:00'),
(6,'EM04',2,'2021-11-20 14:00:00'),
(1,'EM05',2,'2022-03-22 08:00:00'),
(1,'EM06',1,'2022-04-20 09:00:00')
-----------------------------------------------------------------
--------------------------  2  -----------------------------------
----------------------CREATE VIEW--------------------------------
CREATE VIEW [EMPLOYEE_TRACKING]
AS
    SELECT e.EmpNo, e.EmpName, e.[Level] 
    FROM EMPLOYEE e 
    WHERE e.[Level] BETWEEN 3 AND 5